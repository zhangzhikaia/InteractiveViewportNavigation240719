// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "NavigationInteractiveTool.h"
#include "InteractiveToolManager.h"
#include "BaseBehaviors/ClickDragBehavior.h"
// for raycast into World
#include "InteractiveViewportNavigationModule.h"
#include "InteractiveNavigationUtils.h"
#include "LevelEditor.h"
#include "IAssetViewport.h"
#include "BaseBehaviors/MouseHoverBehavior.h"
#include "Framework/Application/SlateApplication.h"
#include "NavigationWidgets/SNavigationManagerWidget.h"

// localization namespace
#define LOCTEXT_NAMESPACE "UUNavigationInteractiveTool"

/*
 * ToolBuilder
 */

UInteractiveTool* UNavigationInteractiveToolBuilder::BuildTool(const FToolBuilderState & SceneState) const
{
	UNavigationInteractiveTool* NewTool = NewObject<UNavigationInteractiveTool>(SceneState.ToolManager);

	NewTool->ManagerWidget = FInteractiveViewportNavigationModule::Get().GetManagerWidget();
		
	return NewTool;
}

void UNavigationInteractiveTool::Setup()
{
	UInteractiveTool::Setup();
	
	EditorViewportClient = &FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor")).GetFirstActiveViewport()->GetAssetViewportClient();
	
	SetupBehaviors();
}

FInputRayHit UNavigationInteractiveTool::BeginHoverSequenceHitTest(const FInputDeviceRay& DevicePos)
{
	FInputRayHit RayHit = ManagerWidget->IsHit(FSlateApplication::Get().GetCursorPos());

	ETransformGizmoPartIdentifier HitPart;
	if (RayHit.bHit)
	{
		HitPart = static_cast<ETransformGizmoPartIdentifier>(RayHit.HitIdentifier);
	}
	else
	{
		HitPart = ETransformGizmoPartIdentifier::Default;
	}
	
	if (HitPart != LastHitPart)
	{
		//如果LastHitPart不为default, 且最新的HitPart不同, 说明此时是结束悬停的瞬间,设置悬停为false
		if (LastHitPart != ETransformGizmoPartIdentifier::Default)
		{
			ManagerWidget->UpdateHoverState(false,static_cast<uint32>(LastHitPart));
		}
		
		LastHitPart = HitPart;
	}
	return RayHit;
}

void UNavigationInteractiveTool::OnBeginHover(const FInputDeviceRay& DevicePos)
{
	ManagerWidget->UpdateHoverState(true,static_cast<uint32>(LastHitPart));
}

FInputRayHit UNavigationInteractiveTool::CanBeginClickDragSequence(const FInputDeviceRay& PressPos)
{
	FInputRayHit RayHit = ManagerWidget->IsHit(FSlateApplication::Get().GetCursorPos());

	LastHitPart = static_cast<ETransformGizmoPartIdentifier>(RayHit.HitIdentifier);
	
	return RayHit;
}


void UNavigationInteractiveTool::OnClickPress(const FInputDeviceRay& PressPos)
{
	CanExecuteClick = true;
	// determine whether we are moving first or second point for the drag sequence
	DragLastPosition = PressPos.ScreenPosition;

	//一旦开始拖拽, 视口不会改变尺寸, 故在此保存 ,减1是因为全屏尺寸为1920(假设, 但设备输入位置为0~1919)
	ViewSizeX = EditorViewportClient->Viewport->GetSizeXY().X -1;
	ViewSizeY = EditorViewportClient->Viewport->GetSizeXY().Y -1;
}


void UNavigationInteractiveTool::OnClickDrag(const FInputDeviceRay& DragPos)
{
	//因为判断过于灵敏, 设计在拖拽一定距离后禁止点击, 而不是直接禁止, 因为拖拽距离为0时,仍愿意视为点击
	if(FVector2D::DistSquared(DragPos.ScreenPosition,DragLastPosition) <= .1f) return;
	
	CanExecuteClick = false;
	
	if(const ELevelViewportType ViewportType = EditorViewportClient->GetViewportType();
		ViewportType != LVT_Perspective)
	{
		EditorViewportClient->SetViewportType(LVT_Perspective);
		switch (ViewportType)
		{
				//Top
			case LVT_OrthoXY:EditorViewportClient->SetViewRotation(SNavigationManagerWidget::LookFromZ);
				break;
				//Bottom
			case LVT_OrthoNegativeXY:EditorViewportClient->SetViewRotation(SNavigationManagerWidget::LookToZ);
				break;
				//Left
			case LVT_OrthoNegativeXZ:EditorViewportClient->SetViewRotation(SNavigationManagerWidget::LookToY);
				break;
				//Right
			case LVT_OrthoXZ:EditorViewportClient->SetViewRotation(SNavigationManagerWidget::LookFromY);
				break;
				//Front
			case LVT_OrthoNegativeYZ:EditorViewportClient->SetViewRotation(SNavigationManagerWidget::LookFromX);
				break;
				//Back
			case LVT_OrthoYZ:EditorViewportClient->SetViewRotation(SNavigationManagerWidget::LookToX);
				break;
			default:break;
		}
	}
	
	
	FVector2D DeltaPitchYaw = (DragPos.ScreenPosition - DragLastPosition)*.5f;
	if(!RotateInNextTime)
	{
		DeltaPitchYaw = FVector2D::Zero();
	}

	//视角跳跃问题 , 在执行跳跃时, 设置鼠标位置, 本次旋转值是不变的, 但下次的DragPos.ScreenPosition - DragLastPosition会急剧跳跃
	bool LocalRotateInNextTime = true;

	//情况1: 视口非全屏, 已超出边界且继续往外移动
	//情况2: 视口已全屏, 处于边界且继续移动仍贴边界(说明鼠标在往外移动
	if((DragPos.ScreenPosition.X <0 && DragPos.ScreenPosition.X < DragLastPosition.X)
		|| (DragPos.ScreenPosition.X == 0 && DragLastPosition.X == 0))
	{
		EditorViewportClient->Viewport->SetMouse(ViewSizeX,EditorViewportClient->Viewport->GetMouseY());
		LocalRotateInNextTime = false;
	}
	
	if((DragPos.ScreenPosition.X > ViewSizeX && DragPos.ScreenPosition.X > DragLastPosition.X)
		||(DragPos.ScreenPosition.X == ViewSizeX && DragLastPosition.X == ViewSizeX))
	{
		EditorViewportClient->Viewport->SetMouse(0,EditorViewportClient->Viewport->GetMouseY());
		LocalRotateInNextTime = false;
	}
	
	if((DragPos.ScreenPosition.Y <0 && DragPos.ScreenPosition.Y < DragLastPosition.Y)
		||(DragPos.ScreenPosition.Y == 0 && DragLastPosition.Y == 0))
	{
		EditorViewportClient->Viewport->SetMouse(EditorViewportClient->Viewport->GetMouseX(),ViewSizeY);
		LocalRotateInNextTime = false;
	}
	
	if((DragPos.ScreenPosition.Y > ViewSizeY && DragPos.ScreenPosition.Y > DragLastPosition.Y)
		||(DragPos.ScreenPosition.Y == ViewSizeY && DragLastPosition.Y == ViewSizeY))
	{
		EditorViewportClient->Viewport->SetMouse(EditorViewportClient->Viewport->GetMouseX(),0);
		LocalRotateInNextTime = false;
	}
	//即else当以上全都不执行时, 需要把下一次旋转设为true
	RotateInNextTime = LocalRotateInNextTime;
	
	FRotator ViewRotation = EditorViewportClient->GetViewRotation();
	ViewRotation.Add(-DeltaPitchYaw.Y,DeltaPitchYaw.X,0.f);
	EditorViewportClient->SetViewRotation(ViewRotation);
	
	DragLastPosition = DragPos.ScreenPosition;
}

void UNavigationInteractiveTool::OnClickRelease(const FInputDeviceRay& ReleasePos)
{
	if(CanExecuteClick == false) return;
	
	switch (LastHitPart)
	{
	case ETransformGizmoPartIdentifier::TranslateXAxis:
		EditorViewportClient->SetViewportType(LVT_OrthoNegativeYZ);
		break;
	case ETransformGizmoPartIdentifier::TranslateYAxis:
		EditorViewportClient->SetViewportType(LVT_OrthoXZ);
		break;
	case ETransformGizmoPartIdentifier::TranslateZAxis:
		EditorViewportClient->SetViewportType(LVT_OrthoXY);
		break;
	case ETransformGizmoPartIdentifier::RotateXAxis:
		EditorViewportClient->SetViewportType(LVT_OrthoYZ);	
		break;
	case ETransformGizmoPartIdentifier::RotateYAxis:
		EditorViewportClient->SetViewportType(LVT_OrthoNegativeXZ);	
		break;
	case ETransformGizmoPartIdentifier::RotateZAxis:
		EditorViewportClient->SetViewportType(LVT_OrthoNegativeXY);	
		break;
		
		default:break;
	}
}

void UNavigationInteractiveTool::SetupBehaviors()
{
	UMouseHoverBehavior* HoverBehavior = NewObject<UMouseHoverBehavior>();
	HoverBehavior->Initialize(this);
	HoverBehavior->SetDefaultPriority(FInputCapturePriority(FInputCapturePriority::DEFAULT_GIZMO_PRIORITY));
	AddInputBehavior(HoverBehavior);
	
	UClickDragInputBehavior* MouseBehavior = NewObject<UClickDragInputBehavior>();
	MouseBehavior->Initialize(this);
	AddInputBehavior(MouseBehavior);
	
}

#undef LOCTEXT_NAMESPACE
